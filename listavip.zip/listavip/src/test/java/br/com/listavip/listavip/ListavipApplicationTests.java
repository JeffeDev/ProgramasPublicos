package br.com.listavip.listavip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListavipApplicationTests {

	@Test
	void contextLoads() {
	}

}
